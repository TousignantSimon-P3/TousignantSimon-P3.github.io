#include "ServiceConnexion.hpp"

bool ServiceConnexion::est_active() const {
    // Dans un vrai projet, on vérifierait une vraie connexion.
    // Pour l'exemple, on simule qu'elle est toujours active.
    return true;
}
