#include <iostream>
#include "Commande.hpp"
/**
 * @brief Programme principal 
 */
int main() {
    // Initialisation des services et des données d'exemple
    ServiceConnexion service_connexion;
    Article article_disponible = {"Stylo", 10};
    Article article_indisponible = {"Cahier", 0};

    // --- Scénario 1 : Commande valide ---
    Commande commande_valide(101);
    commande_valide.ajouter_article(article_disponible);
    commande_valide.traiter_commande(service_connexion);

    // --- Scénario 2 : Commande avec un article en rupture de stock ---
    Commande commande_stock_epuise(102);
    commande_stock_epuise.ajouter_article(article_disponible);
    commande_stock_epuise.ajouter_article(article_indisponible);
    commande_stock_epuise.traiter_commande(service_connexion);

    // --- Scénario 3 : Commande invalide (pas d'articles) ---
    Commande commande_vide(103);
    commande_vide.traiter_commande(service_connexion);

    // --- Scénario 4 : Commande avec ID invalide ---
    Commande commande_id_invalide(-1);
    commande_id_invalide.ajouter_article(article_disponible);
    commande_id_invalide.traiter_commande(service_connexion);

    return 0;
}
