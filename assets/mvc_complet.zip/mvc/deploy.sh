#!/bin/bash

# --- Couleurs pour la lisibilité ---
GREEN='\033[0;32m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== Script de Déploiement MVC - Programmation 3 ===${NC}\n"

# 1. Vérification de CMake
if ! command -v cmake &> /dev/null; then
    echo -e "${RED}[ERREUR] CMake n'est pas installé.${NC}"
    exit 1
fi
echo -e "${GREEN}[OK] CMake trouvé.${NC}"

# 2. Vérification de Qt6
# On teste plusieurs méthodes car les environnements varient (WSL, Linux natif, Windows)
QT_FOUND=false
if cmake --find-package -DNAME=Qt6 -DCOMPILER_ID=GNU -DLANGUAGE=CXX -DMODE=EXIST &> /dev/null; then
    QT_FOUND=true
elif qmake6 --version &> /dev/null; then
    QT_FOUND=true
elif [ -d "/usr/lib/x86_64-linux-gnu/qt6" ] || [ -d "/usr/include/qt6" ]; then
    QT_FOUND=true
fi

if [ "$QT_FOUND" = false ]; then
    echo -e "${RED}[ERREUR] Qt6 n'a pas été trouvé sur votre système.${NC}"
    echo "Conseil : sudo apt install qt6-base-dev"
    exit 1
fi
echo -e "${GREEN}[OK] Qt6 trouvé.${NC}"

# 3. Préparation du dossier Build
if [ ! -d "build" ]; then
    echo -e "${BLUE}Création du dossier build...${NC}"
    mkdir build
fi

cd build

# 4. Configuration CMake
echo -e "${BLUE}\nConfiguration du projet...${NC}"
cmake ..
if [ $? -ne 0 ]; then
    echo -e "${RED}[ERREUR] La configuration CMake a échoué.${NC}"
    exit 1
fi

# 5. Compilation
echo -e "${BLUE}\nCompilation...${NC}"
make -j$(nproc)
if [ $? -ne 0 ]; then
    echo -e "${RED}[ERREUR] La compilation a échoué.${NC}"
    exit 1
fi

echo -e "${GREEN}\n=== SUCCÈS ===${NC}"
echo -e "Pour lancer l'application : ${BLUE}./build/MVC_Client${NC}"
