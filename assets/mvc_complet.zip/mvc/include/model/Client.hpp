#pragma once
#include <string>
#include <stdexcept>

struct DateNaissance {
    int jour;
    int mois;
    int annee;
};

class Client {
public:
    Client() : m_nom(""), m_prenom(""), m_date({1, 1, 2000}) {}
    Client(std::string nom, std::string prenom, DateNaissance date)
        : m_nom(nom), m_prenom(prenom), m_date(date) {}

    std::string getNom() const { return m_nom; }
    void setNom(const std::string& nom) { m_nom = nom; }

    std::string getPrenom() const { return m_prenom; }
    void setPrenom(const std::string& prenom) { m_prenom = prenom; }

    DateNaissance getDate() const { return m_date; }
    void setDate(DateNaissance date) { m_date = date; }

    void genererErreurVolontaire() {
        throw std::runtime_error("Erreur critique : Le modèle a détecté une anomalie !");
    }

private:
    std::string m_nom;
    std::string m_prenom;
    DateNaissance m_date;
};
