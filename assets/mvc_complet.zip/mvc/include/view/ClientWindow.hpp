#pragma once
#include <QMainWindow>  // Équivalent C# : Form / Window
#include <QLineEdit>    // Équivalent Web : <input type="text"> | C# : TextBox
#include <QDateEdit>    // Équivalent Web : <input type="date"> | C# : DateTimePicker
#include <QLabel>       // Équivalent Web : <span> / <label>    | C# : Label
#include <QPushButton>  // Équivalent Web : <button>            | C# : Button

class ClientWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit ClientWindow(QWidget *parent = nullptr);

    QString getNom() const;
    QString getPrenom() const;
    QDate getDate() const;
    void updateSummary(const QString& texte);
    void afficherErreur(const QString& message);

signals:
    void boutonAppliquerClique();
    void boutonErreurClique();

private:
    QLineEdit*   m_editNom;
    QLineEdit*   m_editPrenom;
    QDateEdit*   m_editDate;
    QLabel*      m_labelSummary;
    QPushButton* m_btnSave;
    QPushButton* m_btnError;

    void setupUI();
};
