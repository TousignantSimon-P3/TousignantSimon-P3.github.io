#pragma once
#include <QObject>
#include "model/Client.hpp"
#include "view/ClientWindow.hpp"

class ClientController : public QObject {
    Q_OBJECT
public:
    ClientController(Client* modele, ClientWindow* vue);

private slots:
    void rafraichirVue();
    void mettreAJourModele();
    void gererErreur();

private:
    Client* m_modele;
    ClientWindow* m_vue;
};
