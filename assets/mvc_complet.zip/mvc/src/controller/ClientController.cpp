#include "controller/ClientController.hpp"
#include <QDate>
#include <stdexcept>

ClientController::ClientController(Client* modele, ClientWindow* vue) 
    : m_modele(modele), m_vue(vue) {
    
    connect(m_vue, &ClientWindow::boutonAppliquerClique, this, &ClientController::mettreAJourModele);
    connect(m_vue, &ClientWindow::boutonErreurClique, this, &ClientController::gererErreur);
}

void ClientController::mettreAJourModele() {
    m_modele->setNom(m_vue->getNom().toStdString());
    m_modele->setPrenom(m_vue->getPrenom().toStdString());
    
    QDate d = m_vue->getDate();
    m_modele->setDate({d.day(), d.month(), d.year()});

    rafraichirVue();
}

void ClientController::gererErreur() {
    try {
        // On appelle le modèle qui va lancer une exception
        m_modele->genererErreurVolontaire();
    } catch (const std::runtime_error& e) {
        // On attrape l'erreur standard et on l'affiche via la Vue
        m_vue->afficherErreur(QString::fromStdString(e.what()));
    }
}

void ClientController::rafraichirVue() {
    QString resume = QString("%1 %2, né(e) le %3/%4/%5")
        .arg(QString::fromStdString(m_modele->getPrenom()))
        .arg(QString::fromStdString(m_modele->getNom()).toUpper())
        .arg(m_modele->getDate().jour)
        .arg(m_modele->getDate().mois)
        .arg(m_modele->getDate().annee);
    
    m_vue->updateSummary(resume);
}
