#include "view/ClientWindow.hpp"
#include <QVBoxLayout>
#include <QFormLayout>
#include <QGroupBox>
#include <QMessageBox>

ClientWindow::ClientWindow(QWidget *parent) : QMainWindow(parent) {
    setupUI();
    connect(m_btnSave, &QPushButton::clicked, this, &ClientWindow::boutonAppliquerClique);
    connect(m_btnError, &QPushButton::clicked, this, &ClientWindow::boutonErreurClique);
}

void ClientWindow::setupUI() {
    auto* centralWidget = new QWidget(this);
    centralWidget->setObjectName("centralWidget");
    auto* mainLayout = new QVBoxLayout(centralWidget);
    mainLayout->setSpacing(15);
    mainLayout->setContentsMargins(20, 20, 20, 20);

    // --- Section Saisie ---
    auto* groupSaisie = new QGroupBox("Informations Personnelles", this);
    auto* formLayout = new QFormLayout(groupSaisie);
    formLayout->setVerticalSpacing(10);

    m_editNom = new QLineEdit(this);
    m_editPrenom = new QLineEdit(this);
    m_editDate = new QDateEdit(QDate::currentDate(), this);
    m_editDate->setCalendarPopup(true);

    formLayout->addRow("Nom :", m_editNom);
    formLayout->addRow("Prénom :", m_editPrenom);
    formLayout->addRow("Date de naissance :", m_editDate);

    // --- Section Résultat ---
    auto* groupResultat = new QGroupBox("État du Modèle", this);
    auto* layoutResultat = new QVBoxLayout(groupResultat);
    m_labelSummary = new QLabel("En attente de saisie...", this);
    m_labelSummary->setObjectName("labelSummary");
    layoutResultat->addWidget(m_labelSummary);

    // --- Boutons ---
    m_btnSave = new QPushButton("Appliquer les modifications", this);
    m_btnSave->setObjectName("btnSave");
    
    m_btnError = new QPushButton("Simuler une Erreur Critique", this);
    m_btnError->setObjectName("btnError");

    mainLayout->addWidget(groupSaisie);
    mainLayout->addWidget(groupResultat);
    mainLayout->addWidget(m_btnSave);
    mainLayout->addWidget(m_btnError);

    // --- STYLE GLOBAL (Le "Maquillage") ---
    this->setStyleSheet(
        "QMainWindow { background-color: #f8f9fa; }"
        "QGroupBox {"
        "  font-weight: bold; border: 1px solid #dcdde1; border-radius: 10px;"
        "  margin-top: 20px; padding-top: 15px; background-color: white;"
        "}"
        "QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top center; padding: 0 10px; color: #2f3640; }"
        "QLineEdit, QDateEdit {"
        "  border: 1px solid #ced4da; border-radius: 5px; padding: 8px; background: white;"
        "}"
        "QLineEdit:focus { border: 2px solid #3498db; }"
        "#btnSave {"
        "  background-color: #2ecc71; color: white; border-radius: 6px; padding: 12px; font-weight: bold; font-size: 14px;"
        "}"
        "#btnSave:hover { background-color: #27ae60; }"
        "#btnError {"
        "  background-color: #e74c3c; color: white; border-radius: 6px; padding: 12px; font-weight: bold;"
        "}"
        "#btnError:hover { background-color: #c0392b; }"
        "#labelSummary {"
        "  color: #2c3e50; font-style: italic; background-color: #f1f2f6; padding: 15px; border-radius: 5px; border: 1px dashed #7f8c8d;"
        "}"
    );

    setCentralWidget(centralWidget);
    setWindowTitle("Client MVC - Design Moderne");
    resize(450, 450);
}

QString ClientWindow::getNom() const { return m_editNom->text(); }
QString ClientWindow::getPrenom() const { return m_editPrenom->text(); }
QDate ClientWindow::getDate() const { return m_editDate->date(); }

void ClientWindow::updateSummary(const QString& texte) {
    m_labelSummary->setText(texte);
}

void ClientWindow::afficherErreur(const QString& message) {
    QMessageBox::critical(this, "Alerte Système", message);
}
