#include <QApplication>
#include "model/Client.hpp"
#include "view/ClientWindow.hpp"
#include "controller/ClientController.hpp"

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);

    Client modele;
    ClientWindow vue;
    vue.show();

    ClientController controleur(&modele, &vue);

    return a.exec();
}
