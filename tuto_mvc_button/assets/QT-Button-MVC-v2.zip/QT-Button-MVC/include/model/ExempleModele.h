#pragma once
#include <string>
#include <vector>
#include "model/ExempleCategorie.h"

class ExempleModele {
public:
    ExempleModele();
    void setActif(bool etat);
    void inverserEtat();
    bool estActif() const;
    std::string getStatutTexte() const;
    const std::vector<ExempleCategorie>& getCategories() const;
private:
    bool m_actif;
    std::vector<ExempleCategorie> m_categories;
};
