#pragma once
#include <string>

struct ExempleCategorie {
    std::string nom;
    double montant;
};
