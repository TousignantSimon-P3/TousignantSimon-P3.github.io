#pragma once
#include <QObject>
#include "model/ExempleModele.h"
#include "view/fenetreprincipale.h"

class ExempleControleur : public QObject {
    Q_OBJECT
public:
    ExempleControleur(ExempleModele* modele, FenetrePrincipale* vue);

// On utilise explicitement 'public slots' pour la clarté pédagogique
public slots:
    void basculerEtat();
    void activer();
    void desactiver();
    void selectionnerCategorie(int index);

private:
    void rafraichirVue();
    ExempleModele* m_modele;
    FenetrePrincipale* m_vue;
};
