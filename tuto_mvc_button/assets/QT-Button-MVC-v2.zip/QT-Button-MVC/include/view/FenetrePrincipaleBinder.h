#pragma once
#include "view/fenetreprincipale.h"
#include "controller/ExempleControleur.h"

class FenetrePrincipaleBinder {
public:
    static void connecter(FenetrePrincipale* vue, ExempleControleur* controleur);
};
