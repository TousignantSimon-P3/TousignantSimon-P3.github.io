#pragma once
#include <QMainWindow>
#include <QPushButton>
#include <QComboBox>
#include <QRadioButton>
#include <string>
#include <vector>
#include "model/ExempleCategorie.h"

QT_BEGIN_NAMESPACE
namespace Ui { class FenetrePrincipale; }
QT_END_NAMESPACE

class FenetrePrincipale : public QMainWindow {
    Q_OBJECT
public:
    explicit FenetrePrincipale(QWidget *parent = nullptr);
    ~FenetrePrincipale();

    void setTexteStatut(const std::string& texte);
    QPushButton* getBoutonModifier() const;
    QComboBox* getComboBoxCategories() const;
    
    // NOUVEAU : Accès aux RadioButtons
    QRadioButton* getRadActif() const;
    QRadioButton* getRadInactif() const;
    
    // NOUVEAU : Méthode pour forcer l'état graphiquement
    void setEtatActif(bool actif);

    void remplirCategories(const std::vector<ExempleCategorie>& categories);

private:
    Ui::FenetrePrincipale *ui;
};
