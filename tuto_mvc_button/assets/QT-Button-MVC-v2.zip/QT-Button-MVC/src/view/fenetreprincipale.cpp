#include "view/fenetreprincipale.h"
#include "ui_fenetreprincipale.h"

FenetrePrincipale::FenetrePrincipale(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::FenetrePrincipale) {
    ui->setupUi(this);
}

FenetrePrincipale::~FenetrePrincipale() {
    delete ui;
}

void FenetrePrincipale::setTexteStatut(const std::string& texte) {
    ui->lblStatut->setText(QString::fromStdString(texte));
}

QPushButton* FenetrePrincipale::getBoutonModifier() const {
    return ui->btnModifier;
}

QComboBox* FenetrePrincipale::getComboBoxCategories() const {
    return ui->cmbCategories;
}

// NOUVEAU : Getters pour les RadioButtons
QRadioButton* FenetrePrincipale::getRadActif() const { return ui->radActif; }
QRadioButton* FenetrePrincipale::getRadInactif() const { return ui->radInactif; }

// NOUVEAU : Mise à jour graphique forcée par le contrôleur
void FenetrePrincipale::setEtatActif(bool actif) {
    // On bloque temporairement les signaux pour éviter de boucler à l'infini
    ui->radActif->blockSignals(true);
    ui->radInactif->blockSignals(true);
    
    ui->radActif->setChecked(actif);
    ui->radInactif->setChecked(!actif);
    
    ui->radActif->blockSignals(false);
    ui->radInactif->blockSignals(false);
}

void FenetrePrincipale::remplirCategories(const std::vector<ExempleCategorie>& categories) {
    ui->cmbCategories->clear();
    for (const auto& cat : categories) {
        QString item = QString::fromStdString(cat.nom) + " (" + QString::number(cat.montant, 'f', 2) + "$)";
        ui->cmbCategories->addItem(item);
    }
}
