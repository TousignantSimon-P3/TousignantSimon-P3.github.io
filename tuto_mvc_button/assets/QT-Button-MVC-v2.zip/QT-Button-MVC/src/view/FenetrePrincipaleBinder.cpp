#include "view/FenetrePrincipaleBinder.h"

void FenetrePrincipaleBinder::connecter(FenetrePrincipale* vue, ExempleControleur* controleur) {
    
    // 1. Bouton : On bascule (Toggle)
    QObject::connect(vue->getBoutonModifier(), &QPushButton::clicked, 
                     controleur, &ExempleControleur::basculerEtat);

    // 2. ComboBox : Sélection de catégorie
    QObject::connect(vue->getComboBoxCategories(), &QComboBox::currentIndexChanged, 
                     controleur, &ExempleControleur::selectionnerCategorie);

    // 3. RadioButtons : Sélection explicite
    // On utilise 'clicked' car il ne demande pas de paramètre booléen
    QObject::connect(vue->getRadActif(), &QRadioButton::clicked, 
                     controleur, &ExempleControleur::activer);

    QObject::connect(vue->getRadInactif(), &QRadioButton::clicked, 
                     controleur, &ExempleControleur::desactiver);
}
