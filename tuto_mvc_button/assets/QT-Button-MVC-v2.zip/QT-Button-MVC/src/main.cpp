#include <QApplication>
#include "model/ExempleModele.h"
#include "view/fenetreprincipale.h"
#include "view/FenetrePrincipaleBinder.h"
#include "controller/ExempleControleur.h"

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);

    // Initialisation des couches
    ExempleModele modele;
    FenetrePrincipale vue;
    ExempleControleur controleur(&modele, &vue);

    // ACTION CRUCIALE : Le branchement (Binding)
    FenetrePrincipaleBinder::connecter(&vue, &controleur);

    vue.show();
    return a.exec();
}
