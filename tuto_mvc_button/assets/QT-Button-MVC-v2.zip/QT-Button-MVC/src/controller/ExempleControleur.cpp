#include "controller/ExempleControleur.h"
#include <format>

ExempleControleur::ExempleControleur(ExempleModele* modele, FenetrePrincipale* vue)
    : m_modele(modele), m_vue(vue) {
    rafraichirVue();
}

void ExempleControleur::basculerEtat() {
    if (m_modele->estActif()) desactiver();
    else activer();
}

void ExempleControleur::activer() {
    m_modele->setActif(true);
    rafraichirVue();
}

void ExempleControleur::desactiver() {
    m_modele->setActif(false);
    rafraichirVue();
}

void ExempleControleur::selectionnerCategorie(int index) {
    auto categories = m_modele->getCategories();
    if (index >= 0 && index < (int)categories.size()) {
        const auto& cat = categories[index];
        std::string info = std::format("Sélection : {} ({:.2f}$)", cat.nom, cat.montant);
        m_vue->setTexteStatut(info);
    }
}

void ExempleControleur::rafraichirVue() {
    m_vue->setTexteStatut(m_modele->getStatutTexte());
    m_vue->remplirCategories(m_modele->getCategories());
    
    // NOUVEAU : On met à jour l'état visuel des boutons radios
    m_vue->setEtatActif(m_modele->estActif());
}
