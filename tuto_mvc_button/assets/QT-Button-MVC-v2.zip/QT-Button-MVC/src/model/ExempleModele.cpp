#include "model/ExempleModele.h"

ExempleModele::ExempleModele() : m_actif(false) {
    m_categories.push_back({"Alimentation", 150.0});
    m_categories.push_back({"Transport", 45.50});
    m_categories.push_back({"Loisirs", 30.0});
}

void ExempleModele::setActif(bool etat) { m_actif = etat; }
void ExempleModele::inverserEtat() { m_actif = !m_actif; }
bool ExempleModele::estActif() const { return m_actif; }
std::string ExempleModele::getStatutTexte() const {
    return m_actif ? "Statut : ACTIF" : "Statut : INACTIF";
}

const std::vector<ExempleCategorie>& ExempleModele::getCategories() const {
    return m_categories;
}
